#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# ─── CONFIG ───────────────────────────────────────────────────────────────────
$PkgDir      = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppDir      = 'C:\hpd-utilities'
$NginxDir    = 'C:\nginx'
$LogDir      = "$AppDir\logs"
$FrontendDir = "$AppDir\frontend"
$JarPath     = "$AppDir\app.jar"
$EnvFile     = "$AppDir\hpd-utilities-backend.env"
$LauncherBat = "$AppDir\start-backend.bat"

# Look for nssm in package tools\ folder first, then fallback to C:\tools\
$NssmExe = "$PkgDir\tools\nssm.exe"
if (-not (Test-Path $NssmExe)) { $NssmExe = 'C:\tools\nssm.exe' }
# ──────────────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "===============================" -ForegroundColor Cyan
Write-Host "  HPD Utilities - Server Setup " -ForegroundColor Cyan
Write-Host "===============================" -ForegroundColor Cyan
Write-Host ""

# ─── CHECK REQUIREMENTS ───────────────────────────────────────────────────────
Write-Host "[1/5] Checking requirements..." -ForegroundColor Yellow
$fail = $false

# Try PATH first, then common install locations
$javaExe = $null
try { $javaExe = (Get-Command java -ErrorAction Stop).Source } catch {}
if (-not $javaExe) {
    $candidates = @(
        'C:\Program Files\Java\jdk-17\bin\java.exe',
        'C:\Program Files\Common Files\Oracle\Java\javapath\java.exe',
        'C:\Program Files\Eclipse Adoptium\jdk-17*\bin\java.exe',
        'C:\Program Files\Microsoft\jdk-17*\bin\java.exe'
    ) | ForEach-Object { Resolve-Path $_ -ErrorAction SilentlyContinue } | Select-Object -First 1
    if ($candidates) { $javaExe = $candidates.Path }
}
if ($javaExe) {
    Write-Host "  [OK] Java found: $javaExe" -ForegroundColor Green
} else {
    Write-Host "  [FAIL] Java not found. Download OpenJDK 17 dan add ke PATH." -ForegroundColor Red
    $fail = $true
}

if (Test-Path $NssmExe) { Write-Host "  [OK] nssm.exe found at $NssmExe" -ForegroundColor Green }
else { Write-Host "  [FAIL] nssm.exe not found. Letak nssm.exe dalam folder tools\ " -ForegroundColor Red; $fail = $true }

if (Test-Path "$NginxDir\nginx.exe") { Write-Host "  [OK] nginx found at $NginxDir" -ForegroundColor Green }
else { Write-Host "  [FAIL] nginx.exe not found at $NginxDir. Extract nginx ke C:\nginx\" -ForegroundColor Red; $fail = $true }

if (Test-Path "$PkgDir\app.jar") { Write-Host "  [OK] app.jar found" -ForegroundColor Green }
else { Write-Host "  [FAIL] app.jar not found in package folder." -ForegroundColor Red; $fail = $true }

# Check index.html — support both flat and browser\ subfolder layouts
$frontendIndexFound = (Test-Path "$PkgDir\frontend\index.html") -or (Test-Path "$PkgDir\frontend\browser\index.html")
if ($frontendIndexFound) { Write-Host "  [OK] Frontend files found" -ForegroundColor Green }
else { Write-Host "  [FAIL] frontend\index.html not found in package folder." -ForegroundColor Red; $fail = $true }

if (Test-Path "$PkgDir\hpd-utilities-backend.env") { Write-Host "  [OK] .env file found" -ForegroundColor Green }
else { Write-Host "  [FAIL] hpd-utilities-backend.env not found in package folder." -ForegroundColor Red; $fail = $true }

if ($fail) {
    Write-Host ""
    Write-Host "Ada requirement yang tak dipenuhi. Sila betulkan dulu, then run semula." -ForegroundColor Red
    exit 1
}

# ─── COPY FILES TO APP DIR ────────────────────────────────────────────────────
Write-Host ""
Write-Host "[2/5] Copying files to $AppDir..." -ForegroundColor Yellow

New-Item -ItemType Directory -Force -Path $AppDir      | Out-Null
New-Item -ItemType Directory -Force -Path $LogDir      | Out-Null
New-Item -ItemType Directory -Force -Path $FrontendDir | Out-Null

Copy-Item -Force "$PkgDir\app.jar" $JarPath
Copy-Item -Force "$PkgDir\hpd-utilities-backend.env" $EnvFile

# Copy frontend — handle browser\ subfolder (Angular 17) or flat layout
if (Test-Path "$PkgDir\frontend\browser\index.html") {
    Copy-Item -Recurse -Force "$PkgDir\frontend\browser\*" $FrontendDir
} else {
    Copy-Item -Recurse -Force "$PkgDir\frontend\*" $FrontendDir
}

Write-Host "  [OK] Files copied" -ForegroundColor Green

# ─── CREATE BATCH LAUNCHER ────────────────────────────────────────────────────
# Use a .bat launcher so JVM --add-opens flags are always applied correctly
$batContent = "@echo off`r`n"
$batContent += "`"$javaExe`" ^`r`n"
$batContent += "  --add-opens java.base/java.lang=ALL-UNNAMED ^`r`n"
$batContent += "  --add-opens java.base/java.util=ALL-UNNAMED ^`r`n"
$batContent += "  --add-opens java.base/java.io=ALL-UNNAMED ^`r`n"
$batContent += "  -jar `"$JarPath`"`r`n"
Set-Content -Path $LauncherBat -Value $batContent -Encoding ASCII

Write-Host "  [OK] Batch launcher created: $LauncherBat" -ForegroundColor Green

# ─── BACKEND SERVICE ──────────────────────────────────────────────────────────
Write-Host ""
Write-Host "[3/5] Installing backend service (hpd-backend)..." -ForegroundColor Yellow

$svc = Get-Service -Name 'hpd-backend' -ErrorAction SilentlyContinue
if ($svc) {
    Write-Host "  Service sedia ada. Stop dan remove dulu..." -ForegroundColor Gray
    & $NssmExe stop hpd-backend confirm 2>&1 | Out-Null
    & $NssmExe remove hpd-backend confirm 2>&1 | Out-Null
    Start-Sleep -Seconds 2
}

& $NssmExe install hpd-backend "cmd.exe"
& $NssmExe set hpd-backend AppParameters "/c `"$LauncherBat`""
& $NssmExe set hpd-backend AppDirectory $AppDir
& $NssmExe set hpd-backend AppEnvironmentExtra "SPRING_CONFIG_LOCATION=file:$EnvFile"
& $NssmExe set hpd-backend AppStdout "$LogDir\backend.log"
& $NssmExe set hpd-backend AppStderr "$LogDir\backend-error.log"
& $NssmExe set hpd-backend AppRotateFiles 1
& $NssmExe set hpd-backend AppRotateBytes 10485760
& $NssmExe set hpd-backend Start SERVICE_AUTO_START
& $NssmExe start hpd-backend

Write-Host "  [OK] hpd-backend service installed and started" -ForegroundColor Green

# ─── NGINX CONFIG ─────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "[4/5] Configuring and installing nginx..." -ForegroundColor Yellow

$frontendPath = $FrontendDir -replace '\\', '/'

$nginxConf = @"
worker_processes 1;
events { worker_connections 1024; }
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile      on;
    keepalive_timeout 65;

    server {
        listen 8081;

        root $frontendPath;
        index index.html;

        access_log logs/hpd-access.log;
        error_log  logs/hpd-error.log;

        location / {
            try_files `$uri `$uri/ /index.html;
        }

        location /api/ {
            proxy_pass         http://127.0.0.1:8080/api/;
            proxy_http_version 1.1;
            proxy_set_header   Host            `$host;
            proxy_set_header   X-Real-IP       `$remote_addr;
            proxy_set_header   X-Forwarded-For `$proxy_add_x_forwarded_for;
            proxy_connect_timeout 60s;
            proxy_read_timeout    60s;
        }
    }
}
"@

Set-Content -Path "$NginxDir\conf\nginx.conf" -Value $nginxConf -Encoding UTF8
Write-Host "  [OK] nginx.conf written" -ForegroundColor Green

$svc = Get-Service -Name 'hpd-nginx' -ErrorAction SilentlyContinue
if ($svc) {
    Write-Host "  Service sedia ada. Removing..." -ForegroundColor Gray
    & $NssmExe stop hpd-nginx confirm 2>&1 | Out-Null
    & $NssmExe remove hpd-nginx confirm 2>&1 | Out-Null
    Start-Sleep -Seconds 2
}

& $NssmExe install hpd-nginx "$NginxDir\nginx.exe"
& $NssmExe set hpd-nginx AppDirectory $NginxDir
& $NssmExe set hpd-nginx Start SERVICE_AUTO_START
& $NssmExe start hpd-nginx

Write-Host "  [OK] hpd-nginx service installed and started" -ForegroundColor Green

# ─── FIREWALL ─────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "[5/5] Configuring firewall..." -ForegroundColor Yellow

if (-not (Get-NetFirewallRule -DisplayName 'HPD Frontend' -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName 'HPD Frontend' -Direction Inbound -Protocol TCP -LocalPort 8081 -Action Allow | Out-Null
    Write-Host "  [OK] Port 8081 dibuka" -ForegroundColor Green
} else {
    Write-Host "  [OK] Firewall rule port 8081 dah ada" -ForegroundColor Green
}

if (-not (Get-NetFirewallRule -DisplayName 'HPD Block Backend External' -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName 'HPD Block Backend External' -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Block | Out-Null
    Write-Host "  [OK] Port 8080 diblock dari luar" -ForegroundColor Green
} else {
    Write-Host "  [OK] Firewall block rule port 8080 dah ada" -ForegroundColor Green
}

# ─── DONE ─────────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "===============================" -ForegroundColor Cyan
Write-Host "  Setup complete!" -ForegroundColor Cyan
Write-Host "===============================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  App URL : http://<server-ip>:8081" -ForegroundColor White
Write-Host "  Logs    : $LogDir" -ForegroundColor White
Write-Host ""
Write-Host "Check status services:" -ForegroundColor Gray
Write-Host "  Get-Service hpd-backend, hpd-nginx" -ForegroundColor Gray
Write-Host ""
